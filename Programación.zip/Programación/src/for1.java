import java.util.Scanner;

public class for1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("numero: ");
        int num = sc.nextInt();

        for (int i = 1; i <= num; i++) {
            System.out.print("tabla del: " + 1);
            for (int j = 1; j <= 10; j++){
                System.out.println((i * j) + "\t");
            }
            System.out.println();
        }
    }
}
