import java.util.Scanner;

public class Ejercicio1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un número entre 1 y 100");
        int numeroint = sc.nextInt();
        while (numeroint < 1 || numeroint > 100) {
            System.out.println("\nno esta bro. \n" + "sigue manin");
            numeroint = sc.nextInt();
        }
        System.out.println("si bbro");
    }
}