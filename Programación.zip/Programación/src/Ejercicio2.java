import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un numero del 1 al 100");
        int num;
        int contador = 0;
        do {
            System.out.println("Introduce un número: ");
            num = sc.nextInt();
            contador++;
        } while (num != 0);
        System.out.println(contador - 1);
    }
}
