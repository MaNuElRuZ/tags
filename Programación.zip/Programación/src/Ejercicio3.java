import java.util.Scanner;

public class Ejercicio3 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Introduce un número");
        //int elbueno = sc.nextInt();
       // int maxtemp = num;//


        //while (num != 0)
            //if (num > maxtemp) {
            //maxtemp = num;//
        //} System.out.println("sig");
        //num = sc.nextInt();
        System.out.println();//
    }

}
